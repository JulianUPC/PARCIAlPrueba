/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author ESTUDIANTES
 */
public class Llantas {
    private String Participantes;
    private String Nombres;
    private String Apellidos;
    private int Numero;
    private int LLanta;
    private double Diametro;
    private double Metros;
    

    public Llantas(String Participantes, String Nombres, String Apellidos,double Diametro,double Metros) {
        this.Participantes = Participantes;
        this.Nombres = Nombres;
        this.Apellidos = Apellidos;
    }
    
    public Llantas(String Participantes, String Nombres, String Apellidos, int Numero, int LLanta,double Diametro) {
        this.Participantes = Participantes;
        this.Nombres = Nombres;
        this.Apellidos = Apellidos;
        this.Numero = Numero;
        this.LLanta = LLanta;
        this.Diametro = Diametro;
        
    }
    public Llantas(double Metros){
        this.Metros = Metros;
    }

   
    

    public String getParticipantes() {
        return Participantes;
    }
    
    public void setParticipantes(String Participantes) {
        this.Participantes = Participantes;
    }

    public String getNombres() {
        return Nombres;
    }
    
    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getApellidos() {
        return Apellidos;
    }
    
    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public int getNumero() {
        return Numero;
    }
    
    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public int getLLanta() {
        return LLanta;
    }
    
     public void setLLanta(int LLanta) {
        this.LLanta = LLanta;
    }
     
      public double getDiametro() {
        return Diametro;
    }

    public void setDiametro(double diametro) {
        this.Diametro = diametro;
    }

    public double getMetros() {
        return Metros;
    }

    public void setMetros(double Metros) {
        this.Metros = Metros;
    }
    
}
