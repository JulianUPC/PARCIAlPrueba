/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package upc.parcial;

import java.util.Scanner;
import modelo.Llantas;

/**
 *
 * @author ESTUDIANTES
 */
public class Parcial {

    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        Llantas competidor1= new Llantas("A","Marcelo", "Contreras", 10, 45,2);
        System.out.println("Competidor "+competidor1.getParticipantes());
        System.out.println("Nombre del competirdor: "+competidor1.getNombres());
        System.out.println("Apellido del competirdor: "+competidor1.getApellidos());
        System.out.println("Numero del competirdor: "+competidor1.getNumero());
        System.out.println("LLanta con la que participa el competirdor: "+competidor1.getLLanta());
        System.out.println("Diametro de la Llanta: "+competidor1.getDiametro()+"m");
        System.out.println("Digite el toral de giros realizada por la llanta del competidor "+competidor1.getParticipantes());
        int GirosA = leer.nextInt();
        System.out.println("     ");
        
        Llantas competidor2= new Llantas("B", "Jose", "Castilla", 25, 7, 2);
        System.out.println("Competidor "+competidor2.getParticipantes());
        System.out.println("Nombre del competirdor: "+competidor2.getNombres());
        System.out.println("Apellido del competirdor: "+competidor2.getApellidos());
        System.out.println("Numero del competirdor: "+competidor2.getNumero());
        System.out.println("LLanta con la que participa el competirdor: "+competidor2.getLLanta());
        System.out.println("Diametro de la Llanta: "+competidor2.getDiametro()+"m");
        int GirosB = leer.nextInt();
        System.out.println("     ");
        
        Llantas competidor3= new Llantas("C", "Andres", "Molina", 9, 14, 2);
        System.out.println("Competidor "+competidor3.getParticipantes());
        System.out.println("Nombre del competirdor: "+competidor3.getNombres());
        System.out.println("Apellido del competirdor: "+competidor3.getApellidos());
        System.out.println("Numero del competirdor: "+competidor3.getNumero());
        System.out.println("LLanta con la que participa el competirdor: "+competidor3.getLLanta());
        System.out.println("Diametro de la Llanta: "+competidor3.getDiametro()+"m");
        int GirosC = leer.nextInt();
        
        System.out.println("GANADOR DE LA COMPETICION");
        
        if (GirosA > GirosB && GirosA > GirosC){
            System.out.println("El ganador es el competidor A");
        }
        if (GirosB > GirosA&& GirosB > GirosC){
            System.out.println("El ganador es el competidor B");
        } 
        if (GirosC > GirosA && GirosC > GirosB){
            System.out.println("El ganador es el competidor C");
        }
        if (GirosA == GirosB && GirosA > GirosC){
            System.out.println("Competidores A y B estan empate");
        }
        if (GirosA > GirosB && GirosA == GirosC){
            System.out.println("Competidores A y C estan empate");
        }
         if (GirosA == GirosB && GirosA == GirosC){
            System.out.println("Los tres competuidores han quedado empate"); 
        }
}
    
}
